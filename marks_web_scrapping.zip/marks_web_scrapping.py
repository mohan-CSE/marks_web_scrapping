import xlwt
import xlrd
from xlutils.copy import copy
workbook = xlwt.Workbook()
worksheet = workbook.add_sheet("marks")
workbook.save("marks.xls")
from selenium import webdriver 

from selenium.webdriver.common.keys import Keys 
import time
from selenium.webdriver.support.ui import Select
file_obj = open("registration_numbers.txt","r+")
PATH=r"C:\Program Files\Google\Chrome\Application\chromedriver.exe"
driver=webdriver.Chrome(PATH)

driver.get("https://doeresults.gitam.edu/onlineresults/pages/newgrdcrdinput1.aspx")

select = Select(driver.find_element_by_id('cbosem'))
select.select_by_visible_text('1')
select.select_by_value('1')
time.sleep(1)
file_obj = open("registration_numbers.txt","r+")
reg = file_obj.readlines()
c = 0
for i in  reg:
    b = i.replace("\n","")
    reg_no = driver.find_element_by_id("txtreg")
    #reg_no.send_keys(Keys.CONTROL + 'a')
    #reg_no.send_keys(Keys.BACKSPACE)
    reg_no.clear()
    reg_no.send_keys(int(b))
    result = driver.find_element_by_id('Button1')
    result.click()
    name = driver.find_element_by_id("lblname")
    grade = driver.find_element_by_class_name("table-responsive")
    point = list(grade.text[215:222])
    #time.sleep(1)
    if "O" in point:
        a = "10"
    elif "A" in point and ("+" in point):
        a = "9"
    elif ("A" in point) and ("b" not in point):
        a = "8"
    elif "B+" in point and ("+" in point):
        a = "7"
    elif "B" in point and("b" not in point):
        a = "6"
    elif "C" in point:
        a = "5"
    elif "P" in point:
        a = "4"
    elif "b" in point:
        a = "absent"
    elif "F" in point:
        a = "Fail"
    time.sleep(2)
    rb = xlrd.open_workbook("marks.xls")
    wb = copy(rb)
    w_sheet = wb.get_sheet("marks")
    w_sheet.write(c,1,name.text)
    w_sheet.write(c,0,b)
    w_sheet.write(c,2,a)
    wb.save("marks.xls")
    c+=1
    driver.back()


